
"""Shared settings for Logic Detective."""

GAME_TITLE = "Logic Detective: The Digital Escape Room"

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 650
FPS = 60

PLAYER_WIDTH = 22
PLAYER_HEIGHT = 28
PLAYER_SPEED = 220

INTERACTION_DISTANCE = 65
FINAL_LEVEL_TIME = 120

# General colors
BLACK = (5, 10, 18)
WHITE = (235, 244, 250)

DARK_BLUE = (9, 20, 33)
PANEL_BLUE = (18, 35, 52)

# Interface colors
CYAN = (35, 235, 245)
GREEN = (70, 230, 125)
RED = (245, 65, 55)
YELLOW = (255, 174, 65)
GREY = (112, 132, 151)

# Laboratory colors
WALL_COLOR = (28, 49, 69)
FLOOR_COLOR = (12, 24, 37)

DOOR_COLOR = (160, 85, 45)
LOCKED_DOOR_COLOR = (190, 55, 55)
UNLOCKED_DOOR_COLOR = GREEN
